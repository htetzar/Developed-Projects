﻿namespace SA43_Team10A_LibrarySystem {
    
    
    public partial class DataSetBookInfo {
        partial class PopularbookDataTable
        {
        }
    }
}
